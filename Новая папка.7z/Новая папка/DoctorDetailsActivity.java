package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.HashMap;

public class DoctorDetailsActivity extends AppCompatActivity {

    private String[][] doctor_details1 =
            {
                    {"Doctor Name : Oleksandr Larin", "Hospital address: City Clinical Hospital No. 4 (Kyiv)", "Exp: 7yrs","Mobile No.: 38(098)933-11-03", "25000"},
                    {"Doctor Name : Maksim Horobeyko", "Hospital address: Regional Clinical Hospital (Lviv)", "Exp: 7yrs","Mobile No.: 38(098)917-79-88", "25700"},
                    {"Doctor Name : Volodimir Palamarchuk", "Hospital address: Regional Clinical Hospital (Dnipro)", "Exp: 7yrs","Mobile No.: 38(098)333-88-20", "24100"},
                    {"Doctor Name : Oleksandr Tovkai", "Hospital address: Clinical Hospital (Odessa)", "Exp: 7yrs","Mobile No.: 38(098)134-56-80", "25000"},
                    {"Doctor Name : Ihor Komisarenko", "Hospital address: Regional Clinical Hospital (Kharkiv)", "Exp: 7yrs","Mobile No.: 38(098)147-24-09", "22250"}
            };

    private String[][] doctor_details2 =
            {
                    {"Doctor Name : Nataliia Zemliana", "Hospital address: Municipal Hospital (Zaporizhia)", "Exp: 7yrs","Mobile No.: 38(098)789-45-32", "23500"},
                    {"Doctor Name : Mykola Hrushko", "Hospital address: Regional Clinical Hospital (Donetsk)", "Exp: 7yrs","Mobile No.: 38(098)456-78-90", "24800"},
                    {"Doctor Name : Tetiana Kovalenko", "Hospital address: City Hospital No. 5 (Khmelnytskyi)", "Exp: 7yrs","Mobile No.: 38(098)123-45-67", "23600"},
                    {"Doctor Name : Andrii Fedorenko", "Hospital address: Regional Clinical Hospital (Chernihiv)", "Exp: 7yrs","Mobile No.: 38(098)987-65-43", "25500"},
                    {"Doctor Name : Valentyna Kovalchuk", "Hospital address: Regional Clinical Hospital (Poltava)", "Exp: 7yrs","Mobile No.: 38(098)876-54-32", "24300"}
            };

    private String[][] doctor_details3 =
            {
                    {"Doctor Name : Serhii Shevchenko", "Hospital address: Municipal Hospital (Vinnytsia)", "Exp: 7yrs","Mobile No.: 38(098)765-43-21", "23800"},
                    {"Doctor Name : Yurii Marchenko", "Hospital address: Regional Clinical Hospital (Sumy)", "Exp: 7yrs","Mobile No.: 38(098)654-32-10", "24900"},
                    {"Doctor Name : Mariia Prokopenko", "Hospital address: City Hospital No. 1 (Rivne)", "Exp: 7yrs","Mobile No.: 38(098)543-21-09", "23400"},
                    {"Doctor Name : Pavlo Kovalenko", "Hospital address: Regional Clinical Hospital (Cherkasy)", "Exp: 7yrs","Mobile No.: 38(098)432-10-98", "24200"},
                    {"Doctor Name : Viktoriia Ponomarenko", "Hospital address: Municipal Hospital (Zhytomyr)", "Exp: 7yrs","Mobile No.: 38(098)321-09-87", "23700"}
            };

    private String[][] doctor_details4 =
            {
                    {"Doctor Name : Artem Ivanov", "Hospital address: City Clinical Hospital No. 2 (Kropyvnytskyi)", "Exp: 7yrs","Mobile No.: 38(098)210-98-76", "24400"},
                    {"Doctor Name : Olena Shevchenko", "Hospital address: Regional Clinical Hospital (Ternopil)", "Exp: 7yrs","Mobile No.: 38(098)109-87-65", "24600"},
                    {"Doctor Name : Bohdan Petrenko", "Hospital address: City Hospital No. 3 (Lutsk)", "Exp: 7yrs","Mobile No.: 38(098)098-76-54", "23900"},
                    {"Doctor Name : Anastasiia Kovalchuk", "Hospital address: Regional Clinical Hospital (Ivano-Frankivsk)", "Exp: 7yrs","Mobile No.: 38(098)987-65-43", "24700"},
                    {"Doctor Name : Mykhailo Mykhailenko", "Hospital address: Municipal Hospital (Mariupol)", "Exp: 7yrs","Mobile No.: 38(098)876-54-32", "25300"}
            };

    private String[][] doctor_details5 =
            {
                    {"Doctor Name : Ivan Ivanenko", "Hospital address: City Clinical Hospital No. 6 (Zaporizhia)", "Exp: 7yrs", "Mobile No.: 38(098)765-43-21", "24800"},
                    {"Doctor Name : Viktoria Petrova", "Hospital address: Regional Clinical Hospital (Lviv)", "Exp: 7yrs","Mobile No.: 38(098)654-32-10", "24200"},
                    {"Doctor Name : Roman Romanchuk", "Hospital address: Regional Clinical Hospital (Kharkiv)", "Exp: 7yrs","Mobile No.: 38(098)543-21-09", "24500"},
                    {"Doctor Name : Vasyl Vasylenko", "Hospital address: City Clinical Hospital No. 7 (Kyiv)", "Exp: 7yrs","Mobile No.: 38(098)432-10-98", "25100"},
                    {"Doctor Name : Oleksii Oleksenko", "Hospital address: Regional Clinical Hospital (Odessa)", "Exp: 7yrs","Mobile No.: 38(098)321-09-87", "24350"}
            };

    TextView tv;
    Button btn;
    String[][] doctor_details = {};
    HashMap<String, String> item;
    ArrayList list;
    SimpleAdapter sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_doctor_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tv = findViewById(R.id.titleODTitle);
        btn = findViewById(R.id.buttonHADBack);

        Intent it = getIntent();
        String title = it.getStringExtra("title");
        tv.setText(title);

        if(title.compareTo("Endocrinologist") == 0)
            doctor_details = doctor_details1;
        else if (title.compareTo("Vascular Surgeon") == 0)
            doctor_details = doctor_details2;
        else if (title.compareTo("Ophthalmologist") == 0)
            doctor_details = doctor_details3;
        else if (title.compareTo("Cardiologist") == 0)
            doctor_details = doctor_details4;
        else
            doctor_details = doctor_details5;

        list = new ArrayList();
        for(int i = 0; i < doctor_details.length; i++){
            item = new HashMap<String, String>();
            item.put( "line1", doctor_details[i][0]);
            item.put( "line2", doctor_details[i][1]);
            item.put( "line3", doctor_details[i][2]);
            item.put( "line4", doctor_details[i][3]);
            item.put( "line5","Cons Fees:" + doctor_details[i][4] + "/-");
            list.add(item);
        }
        sa = new SimpleAdapter(this,list,
                R.layout.multi_lines,
                new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e}
        );
        ListView lst = findViewById(R.id.listViewHA);
        lst.setAdapter(sa);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DoctorDetailsActivity.this, FindDoctorActivity.class));
            }
        });

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                Intent it = new Intent(DoctorDetailsActivity.this, BookAppointmentActivity.class);
                it.putExtra("text1", doctor_details[i][0]);
                it.putExtra("text2", doctor_details[i][1]);
                it.putExtra("text3", doctor_details[i][3]);
                it.putExtra("text4", doctor_details[i][4]);
                startActivity(it);
            }
        });
    }
}