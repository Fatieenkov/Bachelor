package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.HashMap;

public class BuyMedicineActivity extends AppCompatActivity {

    private  String[][] packages =
            {
                    {"Metformin", "", "", "", "50"},
                    {"Glimepiride", "", "", "", "250"},
                    {"Sitagliptin", "", "", "", "75"},
                    {"Exenatide", "", "", "", "100"},
                    {"Canagliflozin", "", "", "", "25"},
                    {"Pioglitazone", "", "", "", "150"},
                    {"Insulin Detemir", "", "", "", "125"},
                    {"Insulin Glargine", "", "", "", "200"},
                    {"Liraglutide", "", "", "", "175"},
                    {"Rosiglitazone", "", "", "", "75"}
            };

    private String[] package_detail =
            {
                    "Improves insulin sensitivity and reduces glucose production in the liver",
                    "Sulfonylureas\n" +
                            "Stimulates the pancreas to release more insulin",
                    "DPP-4 Inhibitors\n" +
                            "Increases incretin levels, which increases insulin secretion and decreases glucagon release",
                    "GLP-1 Receptor Agonists\n" +
                            "Enhances insulin secretion, reduces glucagon secretion, and slows gastric emptying",
                    "SGLT2 Inhibitors\n" +
                            "Lowers blood glucose levels by causing the kidneys to remove glucose through the urine",
                    "Thiazolidinediones\n" +
                            "Improves insulin sensitivity in muscle and fat tissues",
                    "Basal Insulin\n" +
                            "Long-acting insulin used to maintain baseline insulin levels",
                    "Basal Insulin\n" +
                            "Long-acting insulin that provides stable insulin levels over 24 hours",
                    "GLP-1 Receptor Agonists\n" +
                            "Increases insulin secretion and decreases glucagon secretion",
                    "Thiazolidinediones\n" +
                            "Enhances insulin sensitivity in muscle and fat tissues"
            };

    HashMap<String, String> item;
    ArrayList list;
    SimpleAdapter sa;
    ListView lst;
    Button btnBack, btnGoToCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_buy_medicine);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lst = findViewById(R.id.listViewHA);
        btnBack = findViewById(R.id.buttonBMBack);
        btnGoToCart = findViewById(R.id.buttonBMCartBack);

        btnGoToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BuyMedicineActivity.this, CartBuyMedicineActivity.class));
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BuyMedicineActivity.this, HomeActivity.class));
            }
        });

        list = new ArrayList();
        for(int i = 0; i < packages.length; i++){
            item =  new HashMap<String, String>();
            item.put("line1", packages[i][0]);
            item.put("line2", packages[i][1]);
            item.put("line3", packages[i][2]);
            item.put("line4", packages[i][3]);
            item.put("line5", "Total Cost: " + packages[i][4] + "/-");
            list.add(item);
        }

        sa = new SimpleAdapter(this,list,
                R.layout.multi_lines,
                new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e});
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                Intent it = new Intent(BuyMedicineActivity.this, BuyMedicineDetailActivity.class);
                it.putExtra("text1", packages[i][0]);
                it.putExtra("text2", package_detail[i]);
                it.putExtra("text3", packages[i][4]);
                startActivity(it);
            }
        });
    }
}